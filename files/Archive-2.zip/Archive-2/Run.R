if (!require("pacman")) install.packages("pacman")
library("pacman")
p_load(readr, dplyr, data.table, tidyr,network, snowFT)
set.seed(123)
p_load(latentnet)
p_load(ergm)
p_load(intergraph)
p_load(parallel)
# PSOCK, RMPI ->
p_load(igraph)
# 1 Load data
d.source.intensity.1996<-fread("pca-source-weights.csv")
# install.packages("ergm",repos="http://www.stat.ucla.edu/~handcock", type="binary")
# install.packages("latentnet",repos="http://www.stat.ucla.edu/~handcock", type="binary")

# 2 Subset Data
countries.of.interest<-c("DEU","IND","ALB","BIH","BGR","HRV","DNK","GRC","ITA","POL","PRT","ROU","SRB","BEL","CAN","ESP","ZAF","TUR","UKR","AUT","CZE","HUN","SVK","LUX","NLD","IRL")
d.source.intensity.1996 <- d.source.intensity.1996[d.source.intensity.1996$Source.Country %in% countries.of.interest, ]
d.source.intensity.1996 <- d.source.intensity.1996[d.source.intensity.1996$Target.Country %in% countries.of.interest, ]

# 3 Prepare data for ERGMM
d.source.intensity.1996.matrix <- as.matrix(d.source.intensity.1996)
g.1996=graph.edgelist(d.source.intensity.1996.matrix[,1:2])
E(g.1996)$weight=as.numeric(d.source.intensity.1996.matrix[,4])
g<-vcount(g.1996) #get number of vertixes
net.1996<-asNetwork(g.1996) #convert to latent network

# 4 Run the model
# Single-processor implementation - works
clust.d2G3r<-ergmm(net.1996~euclidean(d=2,G=4)+rreceiver+rsender,
                   verbose=TRUE)
proc.time()              
# Multiple-processor implementation - works
# The algorithm is stuck with "Burin in..."
clust.d2G3r<-ergmm(net.1996~euclidean(d=2,G=4)+rreceiver+rsender,
                   verbose=TRUE,
                   control=control.ergmm(threads = 2)) #,
#                                        kl.threads = 4))
proc.time()

clust.d2G3r<-ergmm(net.1996~euclidean(d=2,G=2)+rreceiver+rsender,
                   verbose=TRUE,
                   control=control.ergmm(threads = 4, kl.threads = 2)) #,
#                                        kl.threads = 4))
proc.time()