## ----setup, include=FALSE------------------------------------------------
if (!require("pacman")) install.packages("pacman")
#install.packages("experiment")
library(pacman)
p_load(readr, dplyr, data.table, tidyr,network, sna, snowFT, igraph)
set.seed(123)
p_load(ergm)
p_load(intergraph)
p_load(latentnet)
p_load(intergraph)
p_load(parallel)
set.seed(123)

## ----echo=FALSE,message=FALSE, include=FALSE-----------------------------
d <- fread("data.csv", stringsAsFactors = F)

## ------------------------------------------------------------------------
d.source.intensity.1996.matrix <- as.matrix(d)
g.1996=graph.edgelist(d.source.intensity.1996.matrix[,1:2])
g<-vcount(g.1996)

net.1996<-asNetwork(g.1996) #convert to latent network
grp = 18
## ------------------------------------------------------------------------
clust.d2G3r<-ergmm(net.1996~euclidean(d=2,G=grp)+rreceiver+rsender,
                   verbose=TRUE,
                   control=control.ergmm(threads = 4,
                   	kl.threads = 4,
                   	burnin = 5040))
proc.time()

## ------------------------------------------------------------------------
countries <- V(g.1996)$name %>% data.table()
names(countries) <- "country"
Z.K.ref <- summary(clust.d2G3r,point.est="pmean")$pmean$Z.K %>% data.table()# Extract a 

names(Z.K.ref) <- c("cluster")
a<-summary(clust.d2G3r,point.est="pmean")$pmean$Z.pZK %>% data.table()#get probabilities for clusters 
names(a) <- paste0("cl", 1:ncol(a))
b<-summary(clust.d2G3r,point.est="pmean")$pmean$Z %>% data.table() #coordinates in latent space
names(b) <- c("x", "y")

d <- data.table(countries,Z.K.ref, a, b)

#' 
## ------------------------------------------------------------------------
bic.results <- bic.ergmm(clust.d2G3r)
bic.names = names(bic.results)
bic.results <- bic.results %>% unname() %>% unlist()

bic.results <- data.table(bic = bic.names,
                          value = bic.results,
                          grp = grp)

#' 
## ------------------------------------------------------------------------
fwrite(d, 'results.csv', 
      append = F, quote = F, row.names = F, sep = ";")

#' 
## ------------------------------------------------------------------------
fwrite(bic.results, 'results-bic.csv', 
      append = F, quote = F, row.names = F, sep = ";")


#' 
## ------------------------------------------------------------------------
png('1-mcmc-diag.png', res = 300)
mcmc.diagnostics(clust.d2G3r) #I want pictures!
dev.off()

#' 
## ------------------------------------------------------------------------
png('2-picture-1.png', res = 600)
picture1<-plot(clust.d2G3r, what="density", rand.eff="receiver")

dev.off()

#' 
## ------------------------------------------------------------------------
png('3-picture-2.png', res = 600)
picture2<-plot(clust.d2G3r, pie=TRUE,labels=TRUE)
dev.off()


