#!/bin/bash
# Email address to notify
#$ -M asobolev
# Notify when
#$ -m bea

. /u/local/Modules/default/init/modules.sh
module load R

Rscript /u/home/a/asobolev/Desktop/NN/Positives-12/Run.R